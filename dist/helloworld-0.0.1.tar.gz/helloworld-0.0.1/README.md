# Installation

```bash
    pip install helloworld
 ```

# Purpose of the module

- Print hello to the user

