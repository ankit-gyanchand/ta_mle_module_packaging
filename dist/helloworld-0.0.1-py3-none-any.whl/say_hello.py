
def say_hello(name=None):
    if name is None:
        print('Hello world!')
        
    else:
        print(f'Hello {name}!')




# import sys

# args = sys.argv


# if len(args) < 2:
    # print('Hello world!')
# else:
    # print(f'Hello {args[1].title()}!')
    